#!/bin/bash -e
yum install -y httpd