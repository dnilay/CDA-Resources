#!/bin/bash -e
service httpd start