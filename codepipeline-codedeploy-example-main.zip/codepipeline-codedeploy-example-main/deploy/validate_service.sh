#!/bin/bash -e

curl -m 5 http://localhost