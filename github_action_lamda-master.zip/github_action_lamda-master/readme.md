# How to deploy a lambda function using github actions?

Repository for the video: https://www.youtube.com/watch?v=UQiRhKgQ5X0
