# Use Case
How to do automated unit testing in CI/CD pipeline for Lambda

# How to run it
Please follow the instructions from the YouTube video: https://www.youtube.com/watch?v=wUvYTmTvmko

